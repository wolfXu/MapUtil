//
//  ViewController.m
//  AESCipher
//
//  Created by Welkin Xie on 8/13/16.
//  Copyright © 2016 WelkinXie. All rights reserved.
//
//  https://github.com/WelkinXie/AESCipher-iOS
//

#import "ViewController.h"
#import "ZTEAESCipher.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *plainText = @"IAmThePlainText";
    NSString *key = @"zxv10confcodevcc";
    NSString* originStr=@"ZXV10Code://tt7yjJqOMXT3RB7o1BVEbmYVIzsuzxGiKYxhV+Iq9ziMUY7mz9Sy8wCiHQQA/b6vBjS0Nz1OQETK+SBsThfP34+Xm840tlAO0mBIf93ZVzL8v/uadogHmZoENCm7qdUI";
    if([originStr hasPrefix:@"ZXV10Code://"]){
        originStr=[originStr substringFromIndex:12];
    }
    NSLog(@"打印日志:%@",originStr);
    NSString *cipherText=@"tt7yjJqOMXT3RB7o1BVEbmYVIzsuzxGiKYxhV+Iq9ziMUY7mz9Sy8wCiHQQA/b6vBjS0Nz1OQETK+SBsThfP34+Xm840tlAO0mBIf93ZVzL8v/uadogHmZoENCm7qdUI";
    NSString *decryptedText = aesDecryptString_scan(cipherText, key);
    if(decryptedText && decryptedText.length>16){
        decryptedText=[decryptedText substringFromIndex:16];
    }
    NSArray* totalParams=[decryptedText componentsSeparatedByString:@"&"];
    NSMutableDictionary* dictParams=[NSMutableDictionary new];
    if(totalParams && totalParams.count>0){
        for (NSString* paramStr in totalParams) {
            NSArray* arrayTemp=[paramStr componentsSeparatedByString:@"="];
            [dictParams setValue:arrayTemp[1] forKey:arrayTemp[0]];
        }
    }
    NSLog(@"decryptedText:%@", decryptedText);
    NSLog(@"dictParams:%@", dictParams);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}




@end
