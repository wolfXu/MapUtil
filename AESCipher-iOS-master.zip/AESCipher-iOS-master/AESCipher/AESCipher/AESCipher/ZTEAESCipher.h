//
//  AESCipher.h
//  AESCipher
//
//  Created by Welkin Xie on 8/13/16.
//  Copyright © 2016 WelkinXie. All rights reserved.
//
//  https://github.com/WelkinXie/AESCipher-iOS
//

#import <Foundation/Foundation.h>

NSString * aesEncryptString_scan(NSString *content, NSString *key);
NSString * aesDecryptString_scan(NSString *content, NSString *key);

NSData * aesEncryptData_scan(NSData *data, NSData *key);
NSData * aesDecryptData_scan(NSData *data, NSData *key);
